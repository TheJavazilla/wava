package javax.swing;

import javax.swing.border.TitledBorder;

import javax.swing.border.Border;

public class BorderFactory {

    public static Border createEmptyBorder(int top, int left, int bottom, int right) {
        // TODO Auto-generated method stub
        return null;
    }

    public static Border createCompoundBorder(Border out, Border in) {
        // TODO Auto-generated method stub
        return null;
    }

    public static TitledBorder createTitledBorder(String string) {
        // TODO Auto-generated method stub
        return null;
    }

}