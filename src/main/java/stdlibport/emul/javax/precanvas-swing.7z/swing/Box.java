package javax.swing;

public class Box {

    public static JComponent createVerticalStrut(int i) {
        // TODO Auto-generated method stub
        return null;
    }

}
