package javax.swing.border;

import java.awt.Font;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

public class TitledBorder implements Border {

    public Font getTitleFont() {
        // TODO Auto-generated method stub
        return null;
    }

    public void setTitleFont(Font deriveFont) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public Insets getBorderInsets(Component c) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isBorderOpaque() {
        // TODO Auto-generated method stub
        return false;
    }

}
